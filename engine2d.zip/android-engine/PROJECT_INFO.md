
# Engine2D

مشروع Android Studio جاهز. افتح مجلد `android-engine/` داخل Android Studio ثم اضغط Run.

راجع `android-engine/README.md` للتوثيق الكامل (الهيكل، شرح المحرك، كيف تضيف بلوكات/كائنات، وأمثلة JSON).
