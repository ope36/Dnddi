package com.example.engine2d.engine.render;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

/**
 * Renderer
 * --------
 * A thin wrapper over Canvas that draws in WORLD space through a Camera.
 * Scenes never call canvas.drawBitmap directly; they use this instead,
 * so the camera transformation stays in one place.
 */
public class Renderer {

    private final Paint paint = new Paint();
    private final Paint fillPaint = new Paint();
    private Canvas canvas;
    private Camera camera;
    private final Rect dst = new Rect();

    public Renderer() {
        paint.setAntiAlias(false);
        paint.setFilterBitmap(false); // pixel-art look
        fillPaint.setAntiAlias(false);
    }

    public void begin(Canvas canvas, Camera camera) {
        this.canvas = canvas;
        this.camera = camera;
    }

    public Canvas rawCanvas() { return canvas; }

    public void drawBitmap(Bitmap bmp, float wx, float wy, float w, float h) {
        if (bmp == null) return;
        int sx = (int) camera.worldToScreenX(wx);
        int sy = (int) camera.worldToScreenY(wy);
        dst.set(sx, sy, sx + (int)(w * camera.zoom), sy + (int)(h * camera.zoom));
        canvas.drawBitmap(bmp, null, dst, paint);
    }

    public void fillRect(float wx, float wy, float w, float h, int color) {
        fillPaint.setColor(color);
        int sx = (int) camera.worldToScreenX(wx);
        int sy = (int) camera.worldToScreenY(wy);
        canvas.drawRect(sx, sy, sx + (int)(w * camera.zoom), sy + (int)(h * camera.zoom), fillPaint);
    }
}
