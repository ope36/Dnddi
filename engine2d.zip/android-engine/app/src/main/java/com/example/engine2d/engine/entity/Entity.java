package com.example.engine2d.engine.entity;

import android.graphics.Canvas;

import com.example.engine2d.engine.physics.AABB;
import com.example.engine2d.engine.render.Renderer;
import com.example.engine2d.engine.world.World;

/**
 * Entity (abstract)
 * -----------------
 * Anything living in the world: player, enemy, item, projectile...
 * Has an AABB for physics/interaction and velocity fields.
 *
 * Subclasses override update/render. To add a new entity type:
 *   1) extend Entity
 *   2) instantiate it and add it to your Scene's entity list
 *   3) call update(dt, world) and render(...) each frame
 */
public abstract class Entity {
    public final AABB box;
    public float vx, vy;
    public boolean onGround;
    public boolean dead;

    public Entity(float x, float y, float w, float h) {
        this.box = new AABB(x, y, w, h);
    }

    public abstract void update(float deltaTime, World world);
    public abstract void render(Renderer r);

    /** Convenience for game-over style logic. */
    public void kill() { dead = true; }
}
