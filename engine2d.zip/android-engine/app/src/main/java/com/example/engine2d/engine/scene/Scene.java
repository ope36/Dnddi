package com.example.engine2d.engine.scene;

import android.graphics.Canvas;
import android.view.MotionEvent;

import com.example.engine2d.engine.core.GameEngine;

/**
 * Scene (abstract)
 * ----------------
 * A scene = one logical screen (main menu, gameplay, editor, pause...).
 * Games just subclass it and implement the 4 hooks below.
 */
public abstract class Scene {
    protected final GameEngine engine;

    public Scene(GameEngine engine) { this.engine = engine; }

    /** Called once when the SceneManager activates this scene. */
    public void onEnter() {}

    /** Called once when the scene is replaced/removed. Free resources here. */
    public void onExit() {}

    /** Called if the Surface size changed. Use it to reposition HUD. */
    public void onSurfaceChanged(int w, int h) {}

    /** Per-frame logic. deltaTime is in seconds. */
    public abstract void update(float deltaTime);

    /** Per-frame drawing. */
    public abstract void render(Canvas canvas);

    /** Touch input (raw). */
    public void onTouch(MotionEvent ev) {}
}
