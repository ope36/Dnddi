package com.example.engine2d.engine.core;

import android.graphics.Canvas;
import android.graphics.Color;
import android.view.SurfaceHolder;

/**
 * GameThread
 * ----------
 * A dedicated background Thread that runs the game loop.
 *
 * WHY a separate thread?
 *   - The UI thread is for UI only. Rendering and physics on the UI thread
 *     produces jank. A dedicated thread gives predictable timing.
 *
 * The loop uses DELTA TIME (seconds since last frame) so game speed is
 * independent of FPS. It also targets ~60 FPS with a simple sleep cap.
 */
public class GameThread extends Thread {

    private static final int TARGET_FPS = 60;
    private static final long TARGET_FRAME_NS = 1_000_000_000L / TARGET_FPS;

    private final SurfaceHolder holder;
    private final GameEngine engine;
    private volatile boolean running = false;

    public GameThread(SurfaceHolder holder, GameEngine engine) {
        this.holder = holder;
        this.engine = engine;
    }

    public void setRunning(boolean r) { this.running = r; }

    @Override
    public void run() {
        long lastTime = System.nanoTime();
        while (running) {
            long frameStart = System.nanoTime();
            float delta = (frameStart - lastTime) / 1_000_000_000f;
            // Clamp delta so a background pause doesn't teleport entities
            if (delta > 0.05f) delta = 0.05f;
            lastTime = frameStart;

            // 1) Update game state
            engine.update(delta);

            // 2) Render: lock canvas -> draw -> unlock
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas != null) {
                    synchronized (holder) {
                        canvas.drawColor(Color.BLACK);
                        engine.render(canvas);
                    }
                }
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }

            // 3) Frame pacing
            long elapsed = System.nanoTime() - frameStart;
            long sleep = TARGET_FRAME_NS - elapsed;
            if (sleep > 0) {
                try { Thread.sleep(sleep / 1_000_000L); }
                catch (InterruptedException ignored) { }
            }
        }
    }
}
