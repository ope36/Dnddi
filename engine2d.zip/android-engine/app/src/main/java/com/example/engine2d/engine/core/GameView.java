package com.example.engine2d.engine.core;

import android.content.Context;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/**
 * GameView
 * --------
 * A SurfaceView that hosts the engine. It's the ONLY View the engine needs,
 * and it can be embedded in ANY Activity (game, editor, menu preview, ...).
 *
 * Why SurfaceView?
 *   It has its own drawing surface separate from the normal view tree,
 *   which lets the game thread draw continuously without stealing UI frames.
 */
public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private final GameEngine engine;
    private GameThread thread;

    public GameView(Context ctx, GameEngine engine) {
        super(ctx);
        this.engine = engine;
        getHolder().addCallback(this);
        setFocusable(true);
    }

    @Override public void surfaceCreated(SurfaceHolder h) {
        thread = new GameThread(h, engine);
        thread.setRunning(true);
        thread.start();
    }

    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int height) {
        // Inform scenes of the new viewport size so they can resize the camera.
        engine.getSceneManager().onSurfaceChanged(w, height);
    }

    @Override public void surfaceDestroyed(SurfaceHolder h) {
        if (thread == null) return;
        thread.setRunning(false);
        boolean retry = true;
        while (retry) {
            try { thread.join(); retry = false; }
            catch (InterruptedException ignored) { }
        }
        thread = null;
    }

    @Override public boolean onTouchEvent(MotionEvent ev) {
        engine.onTouch(ev);
        return true;
    }
}
