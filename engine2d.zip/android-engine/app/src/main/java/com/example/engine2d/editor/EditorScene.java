package com.example.engine2d.editor;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;

import com.example.engine2d.engine.core.GameEngine;
import com.example.engine2d.engine.render.Camera;
import com.example.engine2d.engine.render.Renderer;
import com.example.engine2d.engine.scene.Scene;
import com.example.engine2d.engine.world.Block;
import com.example.engine2d.engine.world.BlockRegistry;
import com.example.engine2d.engine.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * EditorScene
 * -----------
 * A very small tile editor that runs INSIDE the engine. It:
 *  - renders the world using the normal engine pipeline
 *  - lets the user pan the camera by dragging with one finger
 *  - places (tap) / removes (long tap on same tile) the selected block
 *
 * Block palette + toolbar are drawn by EditorActivity on top as ordinary
 * Android Views, so this scene doesn't need to implement retro widgets.
 */
public class EditorScene extends Scene {

    public final World world;
    public final Camera camera = new Camera();
    public int selectedBlockId = 1;
    public boolean erase;           // set from the palette "Erase" button

    private final Renderer renderer = new Renderer();
    private final Paint grid = new Paint();
    private final Paint hud  = new Paint();
    private float lastX, lastY;
    private boolean dragging;

    public EditorScene(GameEngine engine) {
        super(engine);
        BlockRegistry reg = new BlockRegistry();
        String json = engine.getResourceManager().loadText("data/tiles.json");
        try { if (json != null) reg.loadFromJson(json); } catch (Exception ignored) {}
        world = new World(reg);

        grid.setColor(Color.argb(60, 0, 0, 0));
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(1f);
        hud.setColor(Color.BLACK);
        hud.setTextSize(32);
        hud.setAntiAlias(true);
    }

    public List<Block> palette() {
        List<Block> list = new ArrayList<>();
        for (Block b : world.getRegistry().all()) if (b.id != 0) list.add(b);
        return list;
    }

    @Override public void onSurfaceChanged(int w, int h) {
        camera.setViewport(w, h);
    }

    @Override public void update(float dt) { /* editor is static */ }

    @Override public void render(Canvas c) {
        c.drawColor(Color.rgb(200, 200, 200));   // retro grey background
        renderer.begin(c, camera);
        world.render(renderer, camera, engine.getResourceManager());
        drawGrid(c);
        c.drawText("Selected: " + (erase ? "ERASE" : "block #" + selectedBlockId),
                   20, camera.viewportH - 20, hud);
    }

    private void drawGrid(Canvas c) {
        int ts = World.TILE_SIZE;
        float x0 = -((camera.x) % ts);
        float y0 = -((camera.y) % ts);
        for (float x = x0; x < camera.viewportW; x += ts)
            c.drawLine(x, 0, x, camera.viewportH, grid);
        for (float y = y0; y < camera.viewportH; y += ts)
            c.drawLine(0, y, camera.viewportW, y, grid);
    }

    @Override public void onTouch(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = ev.getX(); lastY = ev.getY(); dragging = false;
                break;
            case MotionEvent.ACTION_MOVE: {
                float dx = ev.getX() - lastX, dy = ev.getY() - lastY;
                if (!dragging && (Math.abs(dx) > 10 || Math.abs(dy) > 10)) dragging = true;
                if (dragging) {
                    camera.x -= dx / camera.zoom;
                    camera.y -= dy / camera.zoom;
                }
                lastX = ev.getX(); lastY = ev.getY();
                break;
            }
            case MotionEvent.ACTION_UP:
                if (!dragging) {
                    // Place/erase tile at tap location
                    int tx = (int) Math.floor(camera.screenToWorldX(ev.getX()) / World.TILE_SIZE);
                    int ty = (int) Math.floor(camera.screenToWorldY(ev.getY()) / World.TILE_SIZE);
                    world.setTile(tx, ty, erase ? 0 : selectedBlockId);
                }
                break;
        }
    }
}
