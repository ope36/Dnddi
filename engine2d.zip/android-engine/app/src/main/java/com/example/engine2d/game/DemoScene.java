package com.example.engine2d.game;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.example.engine2d.engine.core.GameEngine;
import com.example.engine2d.engine.entity.Entity;
import com.example.engine2d.engine.entity.Player;
import com.example.engine2d.engine.input.VirtualButtons;
import com.example.engine2d.engine.io.SaveManager;
import com.example.engine2d.engine.render.Camera;
import com.example.engine2d.engine.render.Renderer;
import com.example.engine2d.engine.scene.Scene;
import com.example.engine2d.engine.world.BlockRegistry;
import com.example.engine2d.engine.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * DemoScene
 * ---------
 * A small game that USES the engine without modifying it. Copy this file
 * to create your own game scene.
 *
 * Steps it performs:
 *   1) load block definitions from assets/data/tiles.json
 *   2) try to load assets/data/world.json OR generate a flat terrain
 *   3) spawn a Player and drive it with on-screen buttons
 *   4) camera follows the player
 */
public class DemoScene extends Scene {

    private final World world;
    private final Camera camera = new Camera();
    private final Renderer renderer = new Renderer();
    private final VirtualButtons buttons;
    private final List<Entity> entities = new ArrayList<>();
    private Player player;
    private final Paint hud = new Paint();

    public DemoScene(GameEngine engine) {
        super(engine);
        BlockRegistry reg = new BlockRegistry();
        try {
            String json = engine.getResourceManager().loadText("data/tiles.json");
            if (json != null) reg.loadFromJson(json);
        } catch (Exception e) { /* registry has AIR by default */ }

        world = new World(reg);

        // Try to load a world bundled in assets; if missing generate one.
        boolean loaded = false;
        String worldJson = engine.getResourceManager().loadText("data/world.json");
        if (worldJson != null) {
            try { loaded = loadFromAssetJson(worldJson); } catch (Exception ignored) {}
        }
        if (!loaded) generateFlatTerrain();

        buttons = new VirtualButtons(engine.getInputManager());
    }

    @Override public void onEnter() {
        player = new Player(
                3 * World.TILE_SIZE,   // spawn x
                4 * World.TILE_SIZE,   // spawn y (above ground)
                engine.getInputManager());
        entities.add(player);

        hud.setColor(Color.WHITE);
        hud.setTextSize(36);
        hud.setAntiAlias(true);
    }

    @Override public void onSurfaceChanged(int w, int h) {
        camera.setViewport(w, h);
        buttons.onSurfaceChanged(w, h);
    }

    @Override public void update(float dt) {
        for (Entity e : entities) e.update(dt, world);
        // Remove dead entities (kept minimal)
        entities.removeIf(e -> e.dead);

        if (player != null) {
            camera.follow(player.box.x + player.box.w / 2, player.box.y + player.box.h / 2);
        }
    }

    @Override public void render(Canvas c) {
        // Sky
        c.drawColor(Color.rgb(120, 190, 255));

        renderer.begin(c, camera);
        world.render(renderer, camera, engine.getResourceManager());
        for (Entity e : entities) e.render(renderer);

        // HUD (screen space)
        c.drawText("Engine2D Demo - FPS ~60", 20, 50, hud);
        buttons.draw(c);
    }

    @Override public void onTouch(android.view.MotionEvent ev) {
        buttons.handleTouch(ev);
    }

    /* ------------------ world helpers ------------------ */

    private void generateFlatTerrain() {
        // 60 tiles wide, ground at row 10
        for (int tx = 0; tx < 60; tx++) {
            world.setTile(tx, 10, 1);   // grass
            for (int ty = 11; ty < 20; ty++) {
                world.setTile(tx, ty, (ty > 13) ? 3 /*stone*/ : 2 /*dirt*/);
            }
        }
        // a small platform
        for (int tx = 15; tx < 20; tx++) world.setTile(tx, 7, 1);
    }

    private boolean loadFromAssetJson(String json) throws Exception {
        // Reuse SaveManager format by letting World consume the json directly.
        // Simple inline parse to avoid file IO:
        org.json.JSONObject root = new org.json.JSONObject(json);
        org.json.JSONArray chunks = root.getJSONArray("chunks");
        for (int i = 0; i < chunks.length(); i++) {
            org.json.JSONObject co = chunks.getJSONObject(i);
            int cx = co.getInt("cx"), cy = co.getInt("cy");
            org.json.JSONArray tiles = co.getJSONArray("tiles");
            for (int j = 0; j < tiles.length(); j++) {
                int id = tiles.getInt(j);
                if (id == 0) continue;
                int lx = j % com.example.engine2d.engine.world.Chunk.SIZE;
                int ly = j / com.example.engine2d.engine.world.Chunk.SIZE;
                world.setTile(cx * com.example.engine2d.engine.world.Chunk.SIZE + lx,
                              cy * com.example.engine2d.engine.world.Chunk.SIZE + ly, id);
            }
        }
        return true;
    }

    // Accessible if you want to persist via SaveManager
    public SaveManager newSaveManager() { return new SaveManager(engine.getContext()); }
    public World getWorld() { return world; }
}
