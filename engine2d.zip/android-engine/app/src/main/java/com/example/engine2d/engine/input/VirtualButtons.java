package com.example.engine2d.engine.input;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;

/**
 * VirtualButtons
 * --------------
 * Three on-screen buttons (left, right, jump). Draws directly to the
 * raw canvas (screen space) and updates InputManager flags.
 *
 * Call handleTouch() from the scene, and draw() last so it appears above
 * the world.
 */
public class VirtualButtons {

    private final InputManager input;
    private final Paint bgPaint = new Paint();
    private final Paint fgPaint = new Paint();
    private final Paint borderPaint = new Paint();

    private int screenW, screenH;
    private int size = 140, pad = 30;

    public VirtualButtons(InputManager input) {
        this.input = input;
        bgPaint.setColor(Color.argb(140, 40, 40, 40));
        fgPaint.setColor(Color.WHITE);
        fgPaint.setTextSize(54);
        fgPaint.setAntiAlias(true);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(3);
        borderPaint.setColor(Color.WHITE);
    }

    public void onSurfaceChanged(int w, int h) {
        this.screenW = w; this.screenH = h;
    }

    private int leftBtnX()  { return pad; }
    private int leftBtnY()  { return screenH - pad - size; }
    private int rightBtnX() { return pad + size + 20; }
    private int rightBtnY() { return screenH - pad - size; }
    private int jumpBtnX()  { return screenW - pad - size; }
    private int jumpBtnY()  { return screenH - pad - size; }

    private boolean inRect(float px, float py, int rx, int ry) {
        return px >= rx && py >= ry && px <= rx + size && py <= ry + size;
    }

    public void handleTouch(MotionEvent ev) {
        input.left = input.right = false;
        boolean anyJump = false;

        for (int i = 0; i < ev.getPointerCount(); i++) {
            float px = ev.getX(i), py = ev.getY(i);
            if (inRect(px, py, leftBtnX(),  leftBtnY()))  input.left  = true;
            if (inRect(px, py, rightBtnX(), rightBtnY())) input.right = true;
            if (inRect(px, py, jumpBtnX(),  jumpBtnY()))  anyJump     = true;
        }

        // Edge-trigger jump
        if (anyJump && !input.jumpHeld) input.triggerJump();
        if (!anyJump) input.releaseJump();

        if (ev.getActionMasked() == MotionEvent.ACTION_UP ||
            ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            input.left = input.right = false;
            input.releaseJump();
        }
    }

    public void draw(Canvas c) {
        drawBtn(c, leftBtnX(),  leftBtnY(),  "◀");
        drawBtn(c, rightBtnX(), rightBtnY(), "▶");
        drawBtn(c, jumpBtnX(),  jumpBtnY(),  "▲");
    }

    private void drawBtn(Canvas c, int x, int y, String label) {
        c.drawRect(x, y, x + size, y + size, bgPaint);
        c.drawRect(x, y, x + size, y + size, borderPaint);
        float tw = fgPaint.measureText(label);
        c.drawText(label, x + size / 2f - tw / 2f, y + size / 2f + 18, fgPaint);
    }
}
