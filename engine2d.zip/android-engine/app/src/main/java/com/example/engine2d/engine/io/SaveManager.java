package com.example.engine2d.engine.io;

import android.content.Context;

import com.example.engine2d.engine.world.Chunk;
import com.example.engine2d.engine.world.World;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * SaveManager
 * -----------
 * World <-> JSON serialization.
 *
 * Layout (world.json):
 *   {
 *     "version": 1,
 *     "tileSize": 48,
 *     "chunks": [
 *       { "cx": 0, "cy": 0, "tiles": [0,0,1,1,...] }   // length = SIZE*SIZE
 *     ]
 *   }
 *
 * Files are stored inside the app's private dir:
 *   context.getFilesDir() + "/worlds/<name>.json"
 */
public class SaveManager {

    private final Context ctx;

    public SaveManager(Context ctx) { this.ctx = ctx; }

    public File worldsDir() {
        File dir = new File(ctx.getFilesDir(), "worlds");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public File worldFile(String name) { return new File(worldsDir(), name + ".json"); }

    /* ---------- save ---------- */

    public void save(String name, World world) throws Exception {
        JSONObject root = new JSONObject();
        root.put("version", 1);
        root.put("tileSize", World.TILE_SIZE);

        JSONArray chunks = new JSONArray();
        for (Map.Entry<Long, Chunk> e : world.chunks().entrySet()) {
            Chunk c = e.getValue();
            JSONObject co = new JSONObject();
            co.put("cx", c.cx);
            co.put("cy", c.cy);
            JSONArray tiles = new JSONArray();
            for (int t : c.raw()) tiles.put(t);
            co.put("tiles", tiles);
            chunks.put(co);
        }
        root.put("chunks", chunks);

        try (FileOutputStream fos = new FileOutputStream(worldFile(name))) {
            fos.write(root.toString().getBytes(StandardCharsets.UTF_8));
        }
    }

    /* ---------- load ---------- */

    public boolean load(String name, World world) throws Exception {
        File f = worldFile(name);
        if (!f.exists()) return false;

        StringBuilder sb = new StringBuilder();
        try (Reader r = new FileReader(f)) {
            char[] buf = new char[4096];
            int n;
            while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
        }

        JSONObject root = new JSONObject(sb.toString());
        JSONArray chunks = root.getJSONArray("chunks");
        for (int i = 0; i < chunks.length(); i++) {
            JSONObject co = chunks.getJSONObject(i);
            int cx = co.getInt("cx");
            int cy = co.getInt("cy");
            JSONArray tiles = co.getJSONArray("tiles");
            for (int j = 0; j < tiles.length(); j++) {
                int id = tiles.getInt(j);
                if (id == 0) continue;
                int lx = j % Chunk.SIZE;
                int ly = j / Chunk.SIZE;
                world.setTile(cx * Chunk.SIZE + lx, cy * Chunk.SIZE + ly, id);
            }
        }
        return true;
    }
}
