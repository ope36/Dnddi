package com.example.engine2d.engine.world;

import android.graphics.Color;

/**
 * Block (tile)
 * ------------
 * A block is a DATA definition, not an instance. The world stores only
 * integer IDs per cell; the registry maps ID -> Block.
 *
 * Fields:
 *   id       : numeric id used in world data (0 = air).
 *   name     : human-readable name, e.g. "grass".
 *   solid    : used by physics (AABB collision).
 *   color    : fallback color when no texture is set.
 *   texture  : optional asset path, e.g. "tiles/grass.png".
 */
public class Block {
    public final int id;
    public final String name;
    public final boolean solid;
    public final int color;
    public final String texture;

    public Block(int id, String name, boolean solid, int color, String texture) {
        this.id = id;
        this.name = name;
        this.solid = solid;
        this.color = color;
        this.texture = texture;
    }

    public static final Block AIR = new Block(0, "air", false, Color.TRANSPARENT, null);
}
