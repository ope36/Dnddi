package com.example.engine2d.engine.world;

/**
 * Chunk
 * -----
 * A fixed-size square of tiles. Using chunks means we don't need to
 * iterate or render the entire world - only the chunks currently
 * intersecting the camera.
 *
 * Default size = 16x16 tiles. Adjust SIZE for your game's needs.
 */
public class Chunk {
    public static final int SIZE = 16;

    public final int cx, cy;        // chunk coords (in chunks, not tiles)
    private final int[] tiles = new int[SIZE * SIZE];
    private boolean dirty = true;

    public Chunk(int cx, int cy) { this.cx = cx; this.cy = cy; }

    public int get(int lx, int ly) {
        if (lx < 0 || ly < 0 || lx >= SIZE || ly >= SIZE) return 0;
        return tiles[ly * SIZE + lx];
    }

    public void set(int lx, int ly, int id) {
        if (lx < 0 || ly < 0 || lx >= SIZE || ly >= SIZE) return;
        tiles[ly * SIZE + lx] = id;
        dirty = true;
    }

    public int[] raw() { return tiles; }

    public boolean isDirty()             { return dirty; }
    public void markClean()              { dirty = false; }
}
