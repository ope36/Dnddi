package com.example.engine2d.engine.core;

import android.content.Context;

/**
 * GameEngine
 * ----------
 * The engine's entry point. It owns the shared services (ResourceManager,
 * SceneManager, InputManager) and hands them to scenes. Any game built
 * on top of this engine only needs an Engine instance + scenes.
 *
 * Lifecycle:
 *   - onCreate:   instantiate services
 *   - start():    called when the Surface is ready (from GameView)
 *   - stop():     called on pause / destroy
 */
public class GameEngine {

    private final Context context;
    private final com.example.engine2d.engine.render.ResourceManager resourceManager;
    private final com.example.engine2d.engine.scene.SceneManager sceneManager;
    private final com.example.engine2d.engine.input.InputManager inputManager;

    public GameEngine(Context context) {
        this.context = context.getApplicationContext();
        this.resourceManager = new com.example.engine2d.engine.render.ResourceManager(this.context);
        this.sceneManager = new com.example.engine2d.engine.scene.SceneManager(this);
        this.inputManager = new com.example.engine2d.engine.input.InputManager();
    }

    public Context getContext()                 { return context; }
    public com.example.engine2d.engine.render.ResourceManager getResourceManager() { return resourceManager; }
    public com.example.engine2d.engine.scene.SceneManager   getSceneManager()   { return sceneManager; }
    public com.example.engine2d.engine.input.InputManager   getInputManager()   { return inputManager; }

    /**
     * Called by GameView once per frame (from GameThread).
     * Delegates to the currently active scene.
     */
    public void update(float deltaTime) {
        sceneManager.update(deltaTime);
    }

    public void render(android.graphics.Canvas canvas) {
        sceneManager.render(canvas);
    }

    public void onTouch(android.view.MotionEvent ev) {
        inputManager.onTouch(ev);
        sceneManager.onTouch(ev);
    }

    /** Release bitmaps / caches. Call from Activity.onDestroy. */
    public void dispose() {
        resourceManager.clear();
    }
}
