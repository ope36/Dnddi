package com.example.engine2d.engine.scene;

import android.graphics.Canvas;
import android.view.MotionEvent;

import com.example.engine2d.engine.core.GameEngine;

/**
 * SceneManager
 * ------------
 * Holds the currently active scene and forwards engine events to it.
 * Switching scenes is atomic and safe from the game thread.
 */
public class SceneManager {

    private final GameEngine engine;
    private Scene current;
    private int surfaceW, surfaceH;

    public SceneManager(GameEngine engine) { this.engine = engine; }

    /** Replace the current scene. Old one receives onExit(), new one onEnter(). */
    public synchronized void setScene(Scene scene) {
        if (current != null) current.onExit();
        current = scene;
        if (current != null) {
            current.onEnter();
            if (surfaceW > 0) current.onSurfaceChanged(surfaceW, surfaceH);
        }
    }

    public Scene getCurrent() { return current; }

    public synchronized void update(float dt)            { if (current != null) current.update(dt); }
    public synchronized void render(Canvas canvas)       { if (current != null) current.render(canvas); }
    public synchronized void onTouch(MotionEvent ev)     { if (current != null) current.onTouch(ev); }
    public synchronized void onSurfaceChanged(int w, int h) {
        this.surfaceW = w; this.surfaceH = h;
        if (current != null) current.onSurfaceChanged(w, h);
    }
}
