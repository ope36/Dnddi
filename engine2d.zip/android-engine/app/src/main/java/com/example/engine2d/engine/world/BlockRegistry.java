package com.example.engine2d.engine.world;

import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * BlockRegistry
 * -------------
 * Central table of all block definitions, loaded from assets/data/tiles.json.
 *
 * Example tiles.json:
 *   {
 *     "blocks": [
 *       { "id": 1, "name": "grass", "solid": true,  "color": "#5aa04a" },
 *       { "id": 2, "name": "dirt",  "solid": true,  "color": "#8b5a2b" },
 *       { "id": 3, "name": "stone", "solid": true,  "color": "#808080",
 *         "texture": "tiles/stone.png" },
 *       { "id": 4, "name": "water", "solid": false, "color": "#3474ff" }
 *     ]
 *   }
 */
public class BlockRegistry {

    private final Map<Integer, Block> byId = new HashMap<>();

    public BlockRegistry() { byId.put(0, Block.AIR); }

    public void loadFromJson(String json) throws Exception {
        JSONObject root = new JSONObject(json);
        JSONArray arr = root.getJSONArray("blocks");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            int id         = o.getInt("id");
            String name    = o.getString("name");
            boolean solid  = o.optBoolean("solid", true);
            int color      = Color.parseColor(o.optString("color", "#ffffff"));
            String texture = o.optString("texture", null);
            byId.put(id, new Block(id, name, solid, color, texture));
        }
    }

    public Block get(int id) {
        Block b = byId.get(id);
        return b == null ? Block.AIR : b;
    }

    public Iterable<Block> all() { return byId.values(); }
    public int size()            { return byId.size(); }
}
