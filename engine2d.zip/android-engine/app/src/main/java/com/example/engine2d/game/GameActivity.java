package com.example.engine2d.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.example.engine2d.engine.core.GameEngine;
import com.example.engine2d.engine.core.GameView;

/**
 * GameActivity
 * ------------
 * Hosts a GameView that runs the engine with our DemoScene. This activity
 * is ~10 lines of logic - all game code lives in DemoScene.
 */
public class GameActivity extends Activity {

    private GameEngine engine;
    private GameView view;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);

        engine = new GameEngine(this);
        engine.getSceneManager().setScene(new DemoScene(engine));
        view = new GameView(this, engine);
        setContentView(view);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (engine != null) engine.dispose();
    }
}
