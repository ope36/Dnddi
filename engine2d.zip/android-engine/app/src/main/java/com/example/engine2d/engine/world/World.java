package com.example.engine2d.engine.world;

import android.graphics.Bitmap;

import com.example.engine2d.engine.render.Camera;
import com.example.engine2d.engine.render.Renderer;
import com.example.engine2d.engine.render.ResourceManager;

import java.util.HashMap;
import java.util.Map;

/**
 * World
 * -----
 * Infinite tile-based world made of Chunks stored in a HashMap keyed by
 * (cx, cy). Tiles are addressed with (tileX, tileY).
 *
 *   tileX, tileY -> chunkX = floor(tileX / Chunk.SIZE), etc.
 *
 * TILE_SIZE is the visual size (world pixels) of ONE tile. Change it to
 * make everything bigger/smaller without touching world data.
 *
 * Performance:
 *   render() walks ONLY the chunks that intersect the camera rect.
 */
public class World {

    public static final int TILE_SIZE = 48;

    private final Map<Long, Chunk> chunks = new HashMap<>();
    private final BlockRegistry registry;

    public World(BlockRegistry registry) { this.registry = registry; }

    public BlockRegistry getRegistry() { return registry; }

    /* --------- tile access ---------- */

    public int getTile(int tx, int ty) {
        Chunk c = chunks.get(key(floorDiv(tx, Chunk.SIZE), floorDiv(ty, Chunk.SIZE)));
        if (c == null) return 0;
        return c.get(Math.floorMod(tx, Chunk.SIZE), Math.floorMod(ty, Chunk.SIZE));
    }

    public void setTile(int tx, int ty, int id) {
        int cx = floorDiv(tx, Chunk.SIZE);
        int cy = floorDiv(ty, Chunk.SIZE);
        Chunk c = chunks.get(key(cx, cy));
        if (c == null) {
            c = new Chunk(cx, cy);
            chunks.put(key(cx, cy), c);
        }
        c.set(Math.floorMod(tx, Chunk.SIZE), Math.floorMod(ty, Chunk.SIZE), id);
    }

    public Map<Long, Chunk> chunks() { return chunks; }

    /* --------- rendering ---------- */

    public void render(Renderer r, Camera cam, ResourceManager res) {
        // World-space rectangle visible on screen
        float vx0 = cam.x;
        float vy0 = cam.y;
        float vx1 = cam.x + cam.viewportW / cam.zoom;
        float vy1 = cam.y + cam.viewportH / cam.zoom;

        int tx0 = (int) Math.floor(vx0 / TILE_SIZE) - 1;
        int ty0 = (int) Math.floor(vy0 / TILE_SIZE) - 1;
        int tx1 = (int) Math.ceil (vx1 / TILE_SIZE) + 1;
        int ty1 = (int) Math.ceil (vy1 / TILE_SIZE) + 1;

        for (int ty = ty0; ty < ty1; ty++) {
            for (int tx = tx0; tx < tx1; tx++) {
                int id = getTile(tx, ty);
                if (id == 0) continue;
                Block b = registry.get(id);
                float wx = tx * TILE_SIZE;
                float wy = ty * TILE_SIZE;
                Bitmap bmp = b.texture != null ? res.loadBitmap(b.texture) : null;
                if (bmp != null) r.drawBitmap(bmp, wx, wy, TILE_SIZE, TILE_SIZE);
                else             r.fillRect(wx, wy, TILE_SIZE, TILE_SIZE, b.color);
            }
        }
    }

    /* --------- helpers ---------- */

    private static long key(int cx, int cy) { return (((long) cx) << 32) ^ (cy & 0xffffffffL); }
    private static int  floorDiv(int a, int b) { return Math.floorDiv(a, b); }
}
