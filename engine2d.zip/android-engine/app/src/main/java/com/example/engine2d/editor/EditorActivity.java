package com.example.engine2d.editor;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.engine2d.R;
import com.example.engine2d.engine.core.GameEngine;
import com.example.engine2d.engine.core.GameView;
import com.example.engine2d.engine.io.SaveManager;
import com.example.engine2d.engine.world.Block;
import com.example.engine2d.engine.world.World;

/**
 * EditorActivity
 * --------------
 * Hosts the EditorScene (inside a GameView) and adds a classic-looking UI:
 *
 *   +----------------------------------------------------+
 *   | [New] [Save] [Load] [Erase]                        |   top bar
 *   +------+---------------------------------------------+
 *   |  P   |                                             |
 *   |  a   |                                             |
 *   |  l   |       engine viewport (GameView)            |
 *   |  e   |                                             |
 *   |  t   |                                             |
 *   |  t   |                                             |
 *   |  e   |                                             |
 *   +------+---------------------------------------------+
 *
 * Style is defined in res/drawable/retro_button.xml and res/values/styles.xml.
 */
public class EditorActivity extends Activity {

    private GameEngine engine;
    private EditorScene editor;
    private SaveManager saves;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_editor);

        engine = new GameEngine(this);
        editor = new EditorScene(engine);
        engine.getSceneManager().setScene(editor);
        saves  = new SaveManager(this);

        GameView gv = new GameView(this, engine);
        ((FrameLayout) findViewById(R.id.viewport)).addView(gv,
            new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                                         ViewGroup.LayoutParams.MATCH_PARENT));

        buildPalette();
        buildTopBar();
    }

    private void buildTopBar() {
        findViewById(R.id.btn_new).setOnClickListener(v -> {
            // Replace current editor scene with a fresh one
            editor = new EditorScene(engine);
            engine.getSceneManager().setScene(editor);
            buildPalette();
            Toast.makeText(this, "New world", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btn_save).setOnClickListener(v -> askName("Save as", name -> {
            try {
                saves.save(name, editor.world);
                Toast.makeText(this, "Saved: " + name, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show();
            }
        }));

        findViewById(R.id.btn_load).setOnClickListener(v -> askName("Load", name -> {
            try {
                editor = new EditorScene(engine);
                engine.getSceneManager().setScene(editor);
                boolean ok = saves.load(name, editor.world);
                Toast.makeText(this, ok ? "Loaded" : "Not found", Toast.LENGTH_SHORT).show();
                buildPalette();
            } catch (Exception e) {
                Toast.makeText(this, "Load failed", Toast.LENGTH_SHORT).show();
            }
        }));

        Button erase = findViewById(R.id.btn_erase);
        erase.setOnClickListener(v -> {
            editor.erase = !editor.erase;
            erase.setText(editor.erase ? "Erase ✓" : "Erase");
        });
    }

    private void buildPalette() {
        LinearLayout list = findViewById(R.id.palette);
        list.removeAllViews();
        for (Block b : editor.palette()) {
            Button btn = new Button(this);
            btn.setText(b.name);
            btn.setTextColor(0xFF000000);
            btn.setBackgroundColor(b.color);
            btn.setPadding(8, 8, 8, 8);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 120);
            lp.setMargins(4, 4, 4, 4);
            btn.setLayoutParams(lp);
            btn.setOnClickListener(v -> {
                editor.selectedBlockId = b.id;
                editor.erase = false;
                ((Button) findViewById(R.id.btn_erase)).setText("Erase");
            });
            list.addView(btn);
        }
    }

    private interface NameConsumer { void accept(String n); }

    private void askName(String title, NameConsumer cb) {
        EditText in = new EditText(this);
        in.setHint("world name");
        in.setText("world1");
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(in)
                .setPositiveButton("OK", (d, w) -> cb.accept(in.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (engine != null) engine.dispose();
    }
}
