package com.example.engine2d.engine.entity;

import android.graphics.Color;

import com.example.engine2d.engine.input.InputManager;
import com.example.engine2d.engine.physics.PhysicsSystem;
import com.example.engine2d.engine.render.Renderer;
import com.example.engine2d.engine.world.World;

/**
 * Player
 * ------
 * Default player entity shipped with the engine. Games may use it as-is
 * or subclass it. Uses InputManager flags (left/right/jump) for movement.
 *
 * To change the player's appearance, either:
 *  - set Player.color (flat color), or
 *  - override render() to draw a bitmap.
 */
public class Player extends Entity {

    public int color = Color.rgb(230, 180, 80);
    public float moveSpeed = 260f;      // px/s
    public float jumpSpeed = 620f;      // px/s
    private final InputManager input;

    public Player(float x, float y, InputManager input) {
        super(x, y, 40, 60);
        this.input = input;
    }

    @Override
    public void update(float dt, World world) {
        // Horizontal input
        float target = 0;
        if (input.left)  target -= moveSpeed;
        if (input.right) target += moveSpeed;
        vx = target;

        // Gravity + jump
        vy += PhysicsSystem.GRAVITY * dt;
        if (input.jumpPressed() && onGround) {
            vy = -jumpSpeed;
            onGround = false;
        }

        // Collisions
        PhysicsSystem.MoveResult mx = PhysicsSystem.moveWithCollisions(box, vx * dt, 0, world);
        if (mx.hitX) vx = 0;

        PhysicsSystem.MoveResult my = PhysicsSystem.moveWithCollisions(box, 0, vy * dt, world);
        if (my.hitY) {
            if (vy > 0) onGround = true;
            vy = 0;
        } else {
            onGround = false;
        }
    }

    @Override
    public void render(Renderer r) {
        r.fillRect(box.x, box.y, box.w, box.h, color);
        // simple eye so it doesn't look like a blank square
        r.fillRect(box.x + box.w * 0.55f, box.y + box.h * 0.2f, 6, 6, Color.BLACK);
    }
}
