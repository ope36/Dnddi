package com.example.engine2d.engine.input;

import android.view.MotionEvent;

/**
 * InputManager
 * ------------
 * Global input state. Virtual on-screen buttons write to these flags, and
 * entities read them. Raw touches are also queued so scenes (e.g. the
 * editor) can consume them for picking / placing.
 *
 * jumpPressed() is edge-triggered: returns true ONCE per press.
 */
public class InputManager {

    // Movement flags, set by VirtualJoystick or direct assignment
    public boolean left, right;
    public boolean jumpHeld;

    // True for exactly one frame after a new jump tap
    private boolean jumpEdge;

    // Last raw touch for generic use (world picking etc.)
    public float lastTouchX, lastTouchY;
    public boolean touchDown;

    public boolean jumpPressed() {
        if (jumpEdge) { jumpEdge = false; return true; }
        return false;
    }

    public void triggerJump() {
        jumpEdge = true;
        jumpHeld = true;
    }

    public void releaseJump() { jumpHeld = false; }

    public void onTouch(MotionEvent ev) {
        int action = ev.getActionMasked();
        lastTouchX = ev.getX();
        lastTouchY = ev.getY();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            touchDown = true;
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            touchDown = false;
        }
    }

    public void reset() {
        left = right = false;
        jumpHeld = false;
        jumpEdge = false;
    }
}
