package com.example.engine2d.engine.render;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * ResourceManager
 * ---------------
 * Loads and caches assets (bitmaps, text) from app/src/main/assets/.
 *
 * - Bitmaps are cached by filename to avoid decoding twice.
 * - Text (JSON) is read on demand.
 *
 * WHERE TO PUT ASSETS:
 *   app/src/main/assets/<subfolder>/<file>
 *   Example:  assets/tiles/grass.png        -> loadBitmap("tiles/grass.png")
 *             assets/data/tiles.json        -> loadText("data/tiles.json")
 */
public class ResourceManager {

    private static final String TAG = "ResourceManager";

    private final AssetManager assets;
    private final Map<String, Bitmap> bitmapCache = new HashMap<>();

    public ResourceManager(Context ctx) {
        this.assets = ctx.getAssets();
    }

    public Bitmap loadBitmap(String path) {
        Bitmap cached = bitmapCache.get(path);
        if (cached != null) return cached;
        try (InputStream is = assets.open(path)) {
            Bitmap bmp = BitmapFactory.decodeStream(is);
            bitmapCache.put(path, bmp);
            return bmp;
        } catch (IOException e) {
            Log.w(TAG, "Could not load bitmap: " + path);
            return null;
        }
    }

    public String loadText(String path) {
        try (InputStream is = assets.open(path);
             BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } catch (IOException e) {
            Log.w(TAG, "Could not load text: " + path);
            return null;
        }
    }

    /** Release cached bitmaps. Call from Activity.onDestroy to avoid leaks. */
    public void clear() {
        for (Bitmap b : bitmapCache.values()) if (b != null && !b.isRecycled()) b.recycle();
        bitmapCache.clear();
    }
}
