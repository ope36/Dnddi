package com.example.engine2d.engine.physics;

import com.example.engine2d.engine.world.Block;
import com.example.engine2d.engine.world.World;

/**
 * PhysicsSystem
 * -------------
 * A very small 2D physics helper for tile-based worlds.
 *
 *   moveWithCollisions(aabb, dx, dy, world)
 *
 * Moves the box on each axis separately; if the new position intersects
 * a solid tile, the axis is reverted. This is the classic "move-by-axis"
 * algorithm used by many 2D platformers. It's cheap and good enough for
 * block games.
 *
 * GRAVITY is a suggested constant entities can use.
 */
public class PhysicsSystem {

    public static final float GRAVITY = 1800f;   // pixels / second^2

    /** Result of a move attempt, so entities know if they touched the ground. */
    public static class MoveResult { public boolean hitX, hitY; }

    public static MoveResult moveWithCollisions(AABB box, float dx, float dy, World world) {
        MoveResult res = new MoveResult();

        // X axis
        box.x += dx;
        if (collidesWithSolid(box, world)) {
            box.x -= dx;
            res.hitX = true;
        }

        // Y axis
        box.y += dy;
        if (collidesWithSolid(box, world)) {
            box.y -= dy;
            res.hitY = true;
        }
        return res;
    }

    public static boolean collidesWithSolid(AABB box, World world) {
        int tx0 = (int) Math.floor(box.x / World.TILE_SIZE);
        int ty0 = (int) Math.floor(box.y / World.TILE_SIZE);
        int tx1 = (int) Math.floor((box.x + box.w - 0.001f) / World.TILE_SIZE);
        int ty1 = (int) Math.floor((box.y + box.h - 0.001f) / World.TILE_SIZE);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                int id = world.getTile(tx, ty);
                if (id == 0) continue;
                Block b = world.getRegistry().get(id);
                if (b.solid) return true;
            }
        }
        return false;
    }
}
