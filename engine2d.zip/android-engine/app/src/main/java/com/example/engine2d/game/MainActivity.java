package com.example.engine2d.game;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.example.engine2d.editor.EditorActivity;

/**
 * MainActivity
 * ------------
 * Simple retro-looking menu with two buttons:
 *   - Play Demo  -> GameActivity
 *   - Open Editor -> EditorActivity
 *
 * UI is defined entirely in activity_main.xml using the retro style.
 */
public class MainActivity extends Activity {

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(com.example.engine2d.R.layout.activity_main);

        findViewById(com.example.engine2d.R.id.btn_play).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, GameActivity.class));
            }
        });

        findViewById(com.example.engine2d.R.id.btn_editor).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, EditorActivity.class));
            }
        });
    }
}
