package com.example.engine2d.engine.physics;

/**
 * AABB (Axis-Aligned Bounding Box)
 * --------------------------------
 * Used by entities and tiles for collision. Coordinates are in WORLD units.
 */
public class AABB {
    public float x, y, w, h;

    public AABB(float x, float y, float w, float h) {
        this.x = x; this.y = y; this.w = w; this.h = h;
    }

    public boolean intersects(AABB o) {
        return x < o.x + o.w && x + w > o.x &&
               y < o.y + o.h && y + h > o.y;
    }
}
