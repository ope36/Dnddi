package com.example.engine2d.engine.render;

/**
 * Camera
 * ------
 * Converts between WORLD coordinates (in pixels) and SCREEN coordinates.
 * A scene moves the camera instead of moving every tile.
 */
public class Camera {
    public float x, y;          // Top-left of the camera in world space
    public int viewportW, viewportH;
    public float zoom = 1.0f;   // 1.0 = no zoom

    public void setViewport(int w, int h) { this.viewportW = w; this.viewportH = h; }

    public void follow(float worldX, float worldY) {
        // Center the camera on the target
        this.x = worldX - viewportW / (2f * zoom);
        this.y = worldY - viewportH / (2f * zoom);
    }

    public float worldToScreenX(float wx) { return (wx - x) * zoom; }
    public float worldToScreenY(float wy) { return (wy - y) * zoom; }
    public float screenToWorldX(float sx) { return sx / zoom + x; }
    public float screenToWorldY(float sy) { return sy / zoom + y; }
}
