# Keep engine classes (reflective JSON loading may use them).
-keep class com.example.engine2d.engine.** { *; }
