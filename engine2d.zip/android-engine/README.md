# Engine2D — محرك ألعاب 2D قابل لإعادة الاستخدام (Android / Java)

> هذا **محرك ألعاب** (Engine) **مع محرر** (Editor) **ولعبة تجريبية** (Demo Game) — وليس لعبة واحدة. كود المحرك معزول تماماً داخل حزم `engine.*`، ويمكنك بناء عدة ألعاب فوقه عن طريق إنشاء Scenes جديدة فقط.

---

## 1. هيكل المشروع الكامل

```
android-engine/                     ← افتح هذا المجلد في Android Studio
├── build.gradle                    ← إعدادات المشروع العليا (plugin version)
├── settings.gradle                 ← تسجيل الوحدات (app)
├── gradle.properties               ← خيارات Gradle العامة (AndroidX, JVM args)
└── app/
    ├── build.gradle                ← إعدادات وحدة التطبيق (minSdk, targetSdk…)
    ├── proguard-rules.pro          ← قواعد ProGuard للإبقاء على كلاسات المحرك
    └── src/main/
        ├── AndroidManifest.xml     ← تعريف الأنشطة الثلاثة
        ├── assets/
        │   ├── data/
        │   │   ├── tiles.json      ← تعريف أنواع البلوكات (ID, لون, صلب؟)
        │   │   └── world.json      ← عالم ابتدائي يُحمّل عند التشغيل
        │   └── tiles/              ← (اختياري) صور PNG للبلوكات
        ├── res/
        │   ├── values/
        │   │   ├── strings.xml
        │   │   ├── colors.xml      ← ألوان الواجهة الريترو
        │   │   └── styles.xml      ← ثيم RetroButton + Theme.Engine2D
        │   ├── drawable/
        │   │   └── retro_button.xml← زر ثلاثي الأبعاد (بنمط Win95)
        │   └── layout/
        │       ├── activity_main.xml
        │       └── activity_editor.xml
        └── java/com/example/engine2d/
            ├── engine/                             ← كود المحرك (قابل لإعادة الاستخدام)
            │   ├── core/
            │   │   ├── GameEngine.java            ← نقطة الدخول: يجمع كل الخدمات
            │   │   ├── GameThread.java            ← حلقة اللعبة (update+render)
            │   │   └── GameView.java              ← SurfaceView يستضيف المحرك
            │   ├── scene/
            │   │   ├── Scene.java                 ← أساس المشاهد (abstract)
            │   │   └── SceneManager.java          ← تبديل المشاهد الآمن
            │   ├── render/
            │   │   ├── Camera.java                ← تحويل World↔Screen
            │   │   ├── Renderer.java              ← رسم عبر الكاميرا
            │   │   └── ResourceManager.java       ← تحميل وتخزين الأصول
            │   ├── world/
            │   │   ├── Block.java                 ← تعريف بلوك
            │   │   ├── BlockRegistry.java         ← قراءة tiles.json
            │   │   ├── Chunk.java                 ← قطعة 16×16 بلوك
            │   │   └── World.java                 ← عالم لا نهائي + رسم مرئي فقط
            │   ├── entity/
            │   │   ├── Entity.java                ← أساس أي كائن متحرك
            │   │   └── Player.java                ← لاعب افتراضي
            │   ├── input/
            │   │   ├── InputManager.java          ← حالة الإدخال العامة
            │   │   └── VirtualButtons.java        ← أزرار on-screen
            │   ├── physics/
            │   │   ├── AABB.java                  ← صندوق تصادم
            │   │   └── PhysicsSystem.java         ← تصادم + جاذبية
            │   └── io/
            │       └── SaveManager.java           ← حفظ/تحميل العالم JSON
            ├── editor/                            ← المحرر (مستقل عن اللعبة)
            │   ├── EditorActivity.java            ← شريط علوي + لوحة جانبية
            │   └── EditorScene.java               ← سحب للتنقل + نقر للوضع
            └── game/                               ← اللعبة التجريبية (مثال على الاستخدام)
                ├── MainActivity.java              ← قائمة رئيسية
                ├── GameActivity.java              ← 10 أسطر تستضيف DemoScene
                └── DemoScene.java                 ← لعبة كاملة تستخدم المحرك
```

**الفكرة**: كل ما بداخل `engine.*` **لا يعرف شيئاً عن اللعبة**. كل ما بداخل `game.*` و`editor.*` يستهلك المحرك.

---

## 2. كيف يعمل المحرك داخلياً

### 2.1 دورة الحياة الكاملة

```
MainActivity  →  GameActivity
                   │
                   ├── new GameEngine(ctx)           // يُنشئ ResourceManager + SceneManager + InputManager
                   ├── sceneManager.setScene(Demo)   // اللعبة تختار مشهدها
                   └── setContentView(new GameView(this, engine))
                              │
                              └── surfaceCreated() → يُطلق GameThread
                                           │
                                           ├── while(running) {
                                           │     engine.update(dt)  ← scene.update
                                           │     engine.render(c)   ← scene.render
                                           │   }
```

### 2.2 حلقة اللعبة (Game Loop) — `GameThread.run()`

تعمل على Thread منفصل (ليس UI Thread) وتتكوّن من 3 مراحل في كل إطار:

1. **حساب delta**: الفرق بين إطار الآن والسابق بالثواني. سرعة اللعبة **مستقلة عن FPS**.
2. **Update**: `engine.update(dt)` ← `scene.update(dt)` ← كل Entity يحدّث نفسه.
3. **Render**: `lockCanvas → scene.render → unlockCanvasAndPost`. `SurfaceView` يسمح بالرسم من Thread آخر بأمان.
4. **ضبط FPS**: ننام ما تبقى من 1/60 ثانية.

### 2.3 الرسم (Rendering)

```
Scene.render(Canvas)
   │
   ├── canvas.drawColor(SKY)                  ← خلفية
   ├── renderer.begin(canvas, camera)         ← ثبت الكاميرا الحالية
   ├── world.render(renderer, camera, res)    ← يحسب فقط البلوكات المرئية
   │        └─ لكل tile داخل camera rect: fillRect أو drawBitmap
   ├── for Entity e: e.render(renderer)       ← اللاعب/الأعداء
   └── buttons.draw(canvas)                   ← HUD في screen-space (بدون كاميرا)
```

**الكاميرا** تعمل كمحوّل إحداثيات:
`worldToScreenX(wx) = (wx - camera.x) * zoom`

### 2.4 الإدخال (Input)

```
GameView.onTouchEvent(MotionEvent)
   → engine.onTouch(ev)
        → inputManager.onTouch(ev)           // يخزن touchDown/lastTouchX…
        → sceneManager.onTouch(ev)           // يمرر للمشهد الحالي
                 → DemoScene: buttons.handleTouch(ev)
                      → input.left/right/jump = true|false
                 → Player.update() يقرأ هذه الأعلام.
```

زر القفز **edge-triggered**: `jumpPressed()` يعود `true` **مرة واحدة فقط** لكل ضغطة.

### 2.5 الفيزياء

`PhysicsSystem.moveWithCollisions(aabb, dx, dy, world)` يحرك الصندوق على محور X ثم Y بشكل منفصل، ويلغي الحركة إذا اصطدم ببلوك صلب. عند الاصطدام على Y بالسرعة الموجبة (السقوط) → `onGround = true`. الجاذبية ثابت `GRAVITY = 1800 px/s²`.

---

## 3. كيف تنشئ لعبة جديدة باستخدام هذا المحرك

**3 خطوات فقط:**

### الخطوة 1 — أنشئ Scene جديد

```java
package com.example.engine2d.game;

public class MyGameScene extends com.example.engine2d.engine.scene.Scene {
    public MyGameScene(com.example.engine2d.engine.core.GameEngine e) { super(e); }

    @Override public void update(float dt)        { /* منطق لعبتك */ }
    @Override public void render(android.graphics.Canvas c) { /* رسم لعبتك */ }
}
```

### الخطوة 2 — أنشئ Activity تستضيفه (انسخ `GameActivity`)

```java
engine = new GameEngine(this);
engine.getSceneManager().setScene(new MyGameScene(engine));
setContentView(new GameView(this, engine));
```

### الخطوة 3 — سجّل Activity في `AndroidManifest.xml`. انتهى. 🎉

---

## 4. كيف تضيف بلوكات جديدة

1. افتح `assets/data/tiles.json`.
2. أضف كائناً جديداً:

```json
{ "id": 8, "name": "glass", "solid": false, "color": "#bde5ff" }
```

3. (اختياري) أضف صورة `assets/tiles/glass.png` وأضف `"texture": "tiles/glass.png"`.
4. أعِد تشغيل التطبيق. البلوك سيظهر تلقائياً في لوحة المحرر.

**قاعدة**: الـ`id = 0` محجوز للهواء (Air). لا تعيد استخدامه.

---

## 5. كيف تضيف كائناً جديداً (Entity)

```java
public class Coin extends Entity {
    public Coin(float x, float y) { super(x, y, 24, 24); }
    @Override public void update(float dt, World w) { /* دوران / التقاط */ }
    @Override public void render(Renderer r) { r.fillRect(box.x, box.y, box.w, box.h, Color.YELLOW); }
}
```

ثم في مشهدك: `entities.add(new Coin(200, 200));` ثم في `update`: `for (Entity e : entities) e.update(dt, world);`

---

## 6. كيف تعدّل شكل اللاعب

طريقتان:

- **الأسهل**: غيّر اللون داخل `Player.java`: `player.color = Color.RED;`
- **الأقوى**: أنشئ `MyPlayer extends Player` وأعِد تعريف `render()`:

```java
@Override public void render(Renderer r) {
    Bitmap bmp = engine.getResourceManager().loadBitmap("sprites/player.png");
    r.drawBitmap(bmp, box.x, box.y, box.w, box.h);
}
```

ثم ضع الصورة في `app/src/main/assets/sprites/player.png`.

---

## 7. الملفات والموارد (Assets)

| نوع | المسار | كيف تحمّله |
|-----|--------|------------|
| PNG بلوك/كائن | `app/src/main/assets/tiles/*.png` | `resManager.loadBitmap("tiles/grass.png")` |
| JSON (بلوكات) | `app/src/main/assets/data/tiles.json` | يقرأها `BlockRegistry` تلقائياً |
| JSON (عالم ابتدائي) | `app/src/main/assets/data/world.json` | يقرأها `DemoScene` عند البدء |
| حفظ من المحرر | `/data/data/<pkg>/files/worlds/<name>.json` | `SaveManager.save("myworld", world)` |

### مثال `tiles.json`

```json
{ "blocks": [
  { "id": 1, "name": "grass", "solid": true, "color": "#5aa04a" },
  { "id": 2, "name": "dirt",  "solid": true, "color": "#8b5a2b" },
  { "id": 3, "name": "stone", "solid": true, "color": "#808080",
    "texture": "tiles/stone.png" }
]}
```

### مثال `world.json` (ملف حفظ)

```json
{ "version": 1, "tileSize": 48,
  "chunks": [
    { "cx": 0, "cy": 0, "tiles": [0,0,0,...,1,1,1,...,2,2,2,...] }
  ]}
```

كل `chunk` يحتوي `SIZE*SIZE = 256` قيمة (`SIZE = 16`). القيمة `0` = هواء، وإلا فهي `id` بلوك من `tiles.json`.

---

## 8. المحرر (Editor)

يعمل داخل نفس التطبيق بأسلوب Win95 / XP:

- **شريط علوي**: `New` / `Save` / `Load` / `Erase`
- **لوحة جانبية**: زر لكل بلوك من `tiles.json`
- **منطقة رئيسية**: نفس الـ `GameView` يُشغّل `EditorScene`
  - **سحب بإصبع** = تحريك الكاميرا
  - **نقرة** = وضع البلوك المحدد (أو مسحه في وضع Erase)

ملفات الحفظ تذهب إلى الذاكرة الخاصة للتطبيق، لذا لا تحتاج أي أذونات.

---

## 9. الأداء والتحسينات

- **Chunks 16×16**: فقط الـ Chunks المتقاطعة مع الشاشة تدخل حلقة الرسم.
- **دالة `World.render()`** تحسب صراحةً `tx0..tx1, ty0..ty1` من rect الكاميرا → **لا بلوك يُرسم خارج الشاشة**.
- **`Paint` واحد مشترك** + `setFilterBitmap(false)` لتسريع bitmap blit.
- **ResourceManager يخزن Bitmaps** فلا تُفكّ نفس الصورة مرتين.
- **`dispose()` في `onDestroy`** يحرر الـ Bitmaps (تجنّب تسريب الذاكرة).
- **Delta clamping** (0.05 ثانية كحد أقصى) يمنع "القفز" بعد العودة من الخلفية.

---

## 10. خطوات التشغيل على Android Studio

1. افتح Android Studio Hedgehog أو أحدث.
2. `File → Open → android-engine/`.
3. عند ظهور رسالة "Sync now" اضغطها (سيُنزل Gradle + SDK).
4. تأكد أن لديك **Android SDK 34** و **Build Tools 34.0.0**.
5. اختر جهازاً/محاكياً (API 24+).
6. اضغط ▶ Run.

أول تشغيل ترى القائمة الرئيسية: زر **Play Demo** (اللعبة) أو **Open Editor** (المحرر).

---

## 11. أين تذهب عند الإضافة؟

| ماذا تريد؟ | أين تعدل؟ |
|-------------|-----------|
| نظام كرافتينغ | أضف `engine/crafting/CraftingSystem.java` + ملف JSON للوصفات |
| أعداء | ورث من `Entity` داخل `game/` (ليس engine، لأن الأعداء خاصون بلعبتك) |
| محرر يرسم كائنات لا بلوكات | أضف وضعاً جديداً في `EditorScene.onTouch` |
| حفظ الكائنات مع العالم | وسّع `SaveManager` ليكتب قائمة Entities |
| موسيقى / أصوات | أنشئ `engine/audio/AudioManager.java` ولفّ `MediaPlayer`/`SoundPool` |

---

## 12. قيود معروفة (فرص لتحسّنها أنت)

- **Canvas API** بدل OpenGL ES → ممتاز للعوب 2D البسيطة، لكن لن يحمل آلاف الكائنات المتحركة معاً.
- **لا يوجد Tilemap Batching** الآن → ارسم إلى Bitmap مؤقت لكل Chunk (pre-render) لتسريع 10×.
- **المحرر لا يضع Entities** حالياً، فقط بلوكات. يمكن توسعته بزرّ "Spawn Player".

---

**الترخيص**: استخدمه كما شئت. هذا مثال تعليمي/بذرة مشروع — أضف ترخيصاً (MIT مثلاً) قبل النشر.
